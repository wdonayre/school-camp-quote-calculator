<?php
//silence is golder