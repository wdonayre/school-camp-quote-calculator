/*
    Author: William Donayre Jr.
    Github: https://github.com/wdonayre
    E-Mail: wdonayredroid@gmail.com
    Date: 08/11/2017
*/
var SCC_Calculator = /** @class */ (function () {
    function SCC_Calculator(_mainWrapper) {
        this._mainWrapper = _mainWrapper;
        this._fieldsArray = [];
        this._total = 0.00;
        this._endpoint = '';
        $ = jQuery;
        this._fields = {};
        this._formSteps = [{}];
        this._breakdown = [];
    }
    SCC_Calculator.prototype.registerEndpointURL = function (url) {
        this._endpoint = url;
    };
    SCC_Calculator.prototype.registerPriceList = function (pl) {
        this._priceList = {};
        this._priceList['mealArray'] = pl;
        for (var key in pl) {
            this._priceList[key] = {};
            if (key === 'accommodation') {
                this._priceList[key] = pl[key];
            }
            else {
                if (pl.hasOwnProperty(key)) {
                    for (var i = 0; i < pl[key].length; i++) {
                        this._priceList[key][pl[key][i]['name']] = pl[key][i];
                        this._priceList[key][pl[key][i]['name']]['index'] = i;
                    }
                }
            }
        }
        console.log(this._priceList);
    };
    SCC_Calculator.prototype.registerFieldArray = function (data) {
        this._fieldsArray.push(data);
    };
    SCC_Calculator.prototype.initializeHeight = function () {
        var windowHeight = $(window).outerHeight();
        $(this._mainWrapper).find('.scc-modal-inner').each(function (index, element) {
            var tmpHeight = $(element).outerHeight();
            $(element).addClass('tmpShow'); //add this class to be able to measure the height
            if ((windowHeight - 80) < $(element).outerHeight()) {
                var newHeight = windowHeight - $(element).find('.scc-modal-header').outerHeight() - $(element).find('.scc-modal-footer').outerHeight() - 80 /* margin top and bottom */;
                $(element).addClass('scc-modal-content-scroll').find('.scc-modal-body').height(newHeight);
            }
            $(element).removeClass('tmpShow'); //remove class to be able to back to initial setup
        });
    };
    SCC_Calculator.prototype.init = function () {
        var obj = this;
        var innerHeight = 0;
        var tallestView = null;
        //let windowHeight:number = $(window).outerHeight();
        /*-------------------------------
          Initialize height and position
        --------------------------------*/
        this.initializeHeight();
        //Initialize button click events || NEXT ||
        $(this._mainWrapper).find('.scc-modal-content .scc-modal-inner').each(function (index, element) {
            // Init Next Button
            $(element).find('.scc-next').on('click', function (e) {
                e.preventDefault();
                //refresh activities fields
                if ($(this).closest('.scc-modal-inner').attr('data-breakdown') === 'activities') {
                    obj._fields.activities = [];
                }
                var valid = obj.validateFields($(element).closest('.scc-modal-inner').find('.form-group input'));
                if (valid && ($(element).closest('.scc-modal-inner').attr('data-view') !== 'breakdown')) {
                    $(element).closest('.scc-modal-inner').hide().removeClass('active');
                    $($(element).closest('.scc-modal-inner').parent().find('.scc-modal-inner')[index + 1]).fadeIn().addClass('active');
                    //process breakdown
                    obj.updateBreakdown($(element).closest('.scc-modal-inner'));
                    //check if current view is now activities
                    if ($($(element).closest('.scc-modal-inner').parent().find('.scc-modal-inner')[index + 1]).attr('data-breakdown') === 'activities') {
                        var activitiesArray = '';
                        for (var activityKey in obj._priceList['activities']) {
                            //console.log(activityKey);
                            if (typeof activityKey !== 'undefined') {
                                var tmpActivity = obj._priceList['activities'][activityKey];
                                var ageGroup = {
                                    'junior': {
                                        min: 3,
                                        max: 7
                                    },
                                    'middle-school': {
                                        min: 8,
                                        max: 9
                                    },
                                    'adults': {
                                        min: 10,
                                        max: 999
                                    }
                                };
                                var allowed = false;
                                var currentAgeGroup = ageGroup[obj._fields.ageGroup];
                                if (tmpActivity.ageGroup.min == null && tmpActivity.ageGroup.max == null) {
                                    allowed = true;
                                }
                                else if (tmpActivity.ageGroup.min == null && (tmpActivity.ageGroup.max >= currentAgeGroup.max)) {
                                    allowed = true;
                                }
                                else if (((tmpActivity.ageGroup.min <= currentAgeGroup.min)) && tmpActivity.ageGroup.max == null) {
                                    allowed = true;
                                }
                                else if (tmpActivity.ageGroup.min <= currentAgeGroup.min && tmpActivity.ageGroup.max >= currentAgeGroup.max) {
                                    allowed = true;
                                }
                                var tmpPrice = (typeof tmpActivity.price.default === 'undefined') ? tmpActivity.price.adults : tmpActivity.price.default;
                                if (allowed) {
                                    activitiesArray += '<div class="col-g-4">' +
                                        '<div class="activity-item form-group" style="background-image:url(http://plugindev.dev/wp-content/plugins/school-camp-calculator/assets/images/mountain-climbing.jpg)">' +
                                        '<label class="activity-item-title">' + tmpActivity.text + '</label>' +
                                        '<span class="activity-item-price">$ ' + tmpPrice + '</span>' +
                                        '<input class="disabled" type="hidden" name="activities" value="' + tmpActivity.name + '" />' +
                                        '</div>' +
                                        '</div>';
                                }
                            }
                        }
                        $($(element).closest('.scc-modal-inner').parent().find('.scc-modal-inner')[index + 1]).find('.activity-selector-wrapper').html(activitiesArray);
                        obj.initializeHeight();
                        obj.reinitializeActivities();
                    }
                    $(element).closest('.scc-modal-content').find('.total-price').each(function (index, element) {
                        $(element).find('span').text('$' + obj.getTotal());
                    });
                    //this.getTotal()
                }
                else {
                    obj.submitFields();
                }
                console.log(obj._fields); //TEMPORARY
                this._total = obj.getTotal();
                console.log(this._total);
            });
            //Init Back Button || BACK ||
            $(element).find('.scc-back').on('click', function (e) {
                e.preventDefault();
                if (index > 0) {
                    $(element).closest('.scc-modal-inner').hide().removeClass('active');
                    $($(element).closest('.scc-modal-inner').parent().find('.scc-modal-inner')[index - 1]).fadeIn().addClass('active');
                }
            });
        });
    };
    /* ---------------------------------- */
    //COMPONENT CLICK EVENT :: Activities //
    /* ---------------------------------- */
    SCC_Calculator.prototype.reinitializeActivities = function () {
        var obj = this;
        $(this._mainWrapper).find('.activity-item').on('click', function (e) {
            e.preventDefault();
            $(this).toggleClass('selected');
            if ($(this).hasClass('selected')) {
                $(this).find('input').removeClass('disabled');
            }
            else {
                $(this).find('input').addClass('disabled');
            }
            if (typeof obj._breakdown['activities'].items !== 'undefined') {
                obj._breakdown['activities'].items = [];
                obj._fields.activities = [];
            }
            var valid = obj.validateFields($(this).closest('.scc-modal-inner').find('.form-group input'));
            if (valid) {
                obj.updateBreakdown($(this).closest('.scc-modal-inner'));
                $(this).closest('.scc-modal-wrapper').find('.total-price span').text('$' + obj.getTotal());
            }
        });
    };
    SCC_Calculator.prototype.updateBreakdown = function (wrapper) {
        var key = $(wrapper).attr('data-breakdown');
        ;
        if (key != undefined && key !== 'end-meal') {
            if (typeof this._breakdown[key] === 'undefined') {
                this._breakdown[key] = {};
            }
        }
        var arrival = new Date(this._fields['arrival-date']);
        var departure = new Date(this._fields['departure-date']);
        var diff = Math.ceil(Math.abs(departure.getTime() - arrival.getTime()) / (1000 * 3600 * 24)); //days/nights stay
        var numAdults = parseInt(this._fields['number-of-adults']);
        var numChild = parseInt(this._fields['number-of-child']);
        if (key === 'accommodation') {
            this._breakdown[key] =
                {
                    text: key,
                    items: [
                        {
                            text: 'Adults',
                            quantity: diff,
                            amount: this._priceList.accommodation.adults * diff * numAdults
                        },
                        {
                            text: 'Child',
                            quantity: diff,
                            amount: this._priceList.accommodation.others * diff * numChild
                        }
                    ]
                };
        }
        else if (key === 'end-meal') {
            var endMealIndex = this._priceList['meals'][this._fields['end-meal']].index;
            console.log("Meal Index: " + endMealIndex);
            var mealKey = 'meals';
            var startMealIndex = this._priceList[mealKey][this._fields.meal].index;
            var mealCount = [];
            var mealItems = [];
            for (var d = 0; d <= diff; d++) {
                for (var m = startMealIndex; m < this._priceList['mealArray'][mealKey].length; m++) {
                    startMealIndex = 0; //back to first meal index
                    var endMealFlag = false;
                    if ((d == (diff)) && (m > endMealIndex)) {
                        endMealFlag = true;
                    }
                    if (endMealFlag == false) {
                        if (typeof mealItems[m] === 'undefined') {
                            mealItems[m] = { text: this._priceList['mealArray'][mealKey][m]['text'], items: [{ text: 'Adults', quantity: 0, amount: 0 }, { text: 'Child', quantity: 0, amount: 0 }] };
                        }
                        //Adults
                        mealItems[m]['items'][0]['quantity'] += 1;
                        mealItems[m]['items'][0]['text'] = 'Adults @ ' + numAdults + 'pax/' + mealItems[m]['items'][0]['quantity'] + 'meal(s)';
                        mealItems[m]['items'][0]['amount'] = mealItems[m]['items'][0]['quantity'] * numAdults * this._priceList[mealKey][this._priceList['mealArray']['meals'][m]['name']]['price']['adults'];
                        //Child
                        mealItems[m]['items'][1]['quantity'] += 1;
                        mealItems[m]['items'][1]['text'] = 'Child @ ' + numChild + 'pax/' + mealItems[m]['items'][1]['quantity'] + 'meal(s)';
                        mealItems[m]['items'][1]['amount'] = mealItems[m]['items'][1]['quantity'] * numChild * this._priceList[mealKey][this._priceList['mealArray']['meals'][m]['name']]['price']['others'];
                    }
                }
            }
            mealItems = this.arrayClean(undefined, mealItems);
            this._breakdown[mealKey] = {
                text: mealKey,
                items: mealItems
            };
        }
        else if (key === 'mealsxxxxxxx') {
            var startMealIndex = this._priceList[key][this._fields.meal].index;
            var mealCount = [];
            var mealItems = [];
            for (var d = 0; d < diff; d++) {
                for (var m = startMealIndex; m < this._priceList['mealArray']['meals'].length; m++) {
                    startMealIndex = 0; //back to first meal index
                    if (typeof mealItems[m] === 'undefined') {
                        mealItems[m] = { text: this._priceList['mealArray']['meals'][m]['text'], items: [{ text: 'Adults', quantity: 0, amount: 0 }, { text: 'Child', quantity: 0, amount: 0 }] };
                    }
                    //Adults
                    mealItems[m]['items'][0]['quantity'] += 1;
                    mealItems[m]['items'][0]['text'] = 'Adults @ ' + numAdults + 'pax/' + mealItems[m]['items'][0]['quantity'] + 'days';
                    mealItems[m]['items'][0]['amount'] = mealItems[m]['items'][0]['quantity'] * numAdults * this._priceList[key][this._priceList['mealArray']['meals'][m]['name']]['price']['adults'];
                    //Child
                    mealItems[m]['items'][1]['quantity'] += 1;
                    mealItems[m]['items'][1]['text'] = 'Child @ ' + numChild + 'pax/' + mealItems[m]['items'][1]['quantity'] + 'days';
                    mealItems[m]['items'][1]['amount'] = mealItems[m]['items'][1]['quantity'] * numChild * this._priceList[key][this._priceList['mealArray']['meals'][m]['name']]['price']['others'];
                }
                mealItems = this.arrayClean(undefined, mealItems);
            }
            this._breakdown[key] = {
                text: key,
                items: mealItems
            };
        }
        else if (key === 'activities') {
            var activityItems = [];
            for (var a = 0; a < this._fields.activities.length; a++) {
                var tmpPrice = (typeof this._priceList['activities'][this._fields.activities[a]]['price']['default'] === 'undefined') ?
                    this._priceList['activities'][this._fields.activities[a]]['price']['adults'] :
                    this._priceList['activities'][this._fields.activities[a]]['price']['default'];
                var totalPax = (parseInt(this._fields['number-of-adults']) + parseInt(this._fields['number-of-child']));
                activityItems[a] = { text: this._priceList['activities'][this._fields.activities[a]]['text'] + ' @ ' + totalPax + 'pax', amount: tmpPrice * totalPax };
            }
            this._breakdown[key] = {
                text: key,
                items: activityItems
            };
        }
        console.log('breakdown:::');
        console.log(this._breakdown);
        this.getTotal();
        this.renderBreakdownView();
    };
    //utility functions
    /*======================================
    
    ======================================*/
    SCC_Calculator.prototype.arrayClean = function (deleteValue, data) {
        for (var i = 0; i < data.length; i++) {
            if (data[i] == deleteValue) {
                data.splice(i, 1);
                i--;
            }
        }
        return data;
    };
    SCC_Calculator.prototype.updateValues = function (field) {
        var key = field.getAttribute('name');
        //check if we registered this field name to be an array or not
        if (this._fieldsArray.indexOf(key) < 0) {
            this._fields[key] = field.value;
        }
        else {
            //make sure .push method for array will work, so we make sure the array is defined.
            if (typeof this._fields[key] === 'undefined') {
                this._fields[key] = [];
            }
            //dont add if the input box is disabled
            if (!($(field).hasClass('disabled'))) {
                this._fields[key].push(field.value);
            }
        }
        //if (!field.hasOwnProperty(key)) {
        // }
        //console.log(this._fields);
    };
    /*======================================
    
    ======================================*/
    SCC_Calculator.prototype.validateFields = function (fields) {
        var ret = true;
        var prevKey = '';
        for (var _i = 0, fields_1 = fields; _i < fields_1.length; _i++) {
            var field = fields_1[_i];
            if ($(field).val().length < 1 && $(field).hasClass('req')) {
                if ($(field).closest('.form-group').find('label.overhead-error').length < 1) {
                    $(field).parent().addClass('form-group-error');
                    $(field).closest('.form-group').append('<label class="overhead-error">Required missing field</label>');
                }
                ret = false;
            }
            else {
                $(field).parent().removeClass('form-group-error');
                $(field).closest('.form-group').find('label.overhead-error').remove();
                //update field values
            }
            //check email field type
            if (field.getAttribute('type') === 'email') {
                if (!(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(field.value))) {
                    if ($(field).closest('.form-group').find('label.overhead-error').length < 1) {
                        $(field).parent().addClass('form-group-error');
                        $(field).closest('.form-group').append('<label class="overhead-error">Invalid Email Address</label>');
                    }
                    ret = false;
                }
            }
            //if radio or checkbox
            var currentKey = field.getAttribute('name');
            if ((field.getAttribute('type') === 'radio')) {
                //
                var tmpField = $(field).closest('.scc-modal-inner').find('input[type="' + field.getAttribute('type') + '"]:checked');
                if ((prevKey !== currentKey) && (tmpField.length > 0)) {
                    this.updateValues(tmpField[0]);
                    prevKey = currentKey;
                }
            }
            else {
                this.updateValues(field);
            }
        }
        return ret;
    };
    /*------------------------
        Compute Total
    ------------------------*/
    SCC_Calculator.prototype.getTotal = function () {
        var ret = 0;
        for (var key in this._breakdown) {
            if (key != undefined) {
                for (var i = 0; i < this._breakdown[key].items.length; i++) {
                    if (key === 'accommodation') {
                        ret += this._breakdown[key].items[i].amount;
                    }
                    else if (key === 'meals') {
                        ret += this._breakdown[key].items[i].items[0].amount + this._breakdown[key].items[i].items[1].amount;
                    }
                    else if (key === 'activities') {
                        ret += this._breakdown[key].items[i].amount;
                    }
                }
            }
        }
        this._total = ret;
        return parseFloat(ret + '').toFixed(2);
    };
    /*------------------------
        Render BreakDown
    ------------------------*/
    SCC_Calculator.prototype.renderBreakdownView = function () {
        var breakdownView = $(this._mainWrapper).find('.scc-modal-inner[data-view="breakdown"] .scc-modal-body .grid');
        this._breakdownSummary = {
            'activities': {},
            'meals': {},
            'accommodation': {}
        };
        //clear contents
        $(breakdownView).html('');
        //NAME
        $(breakdownView).append('<div class="col-50p m-b-10 info-wrapper"><div class="info-group"><label>Name</label><span>' + this._fields.name + '</span></div></div>');
        //EMAIL
        $(breakdownView).append('<div class="col-50p m-b-10 info-wrapper"><div class="info-group"><label>Email</label><span>' + this._fields.email + '</span></div></div>');
        //LABEL --> Breakdown
        $(breakdownView).append('<div class="col-100p m-b-10"><label>BREAKDOWN</label></div><br>');
        var tmpTables = '';
        //ACCOMMODATION
        tmpTables += '<table class="scc-table">' + '<thead>' + '<tr>' + '<th colspan="2">Accommodation</th>' + '</tr>' + '</thead>' + '<tbody>' + '<tr>' + '<td>' + this._breakdown['accommodation']['items'][0].text + '@' + this._fields['number-of-adults'] + 'pax/' + this._breakdown['accommodation']['items'][0].quantity + 'days' + '</td>' + '<td class="text-right">$' + parseFloat(this._breakdown['accommodation']['items'][0].amount).toFixed(2) + '</td>' + '</tr>' + '<tr>' + '<td>' + this._breakdown['accommodation']['items'][1].text + '@' + this._fields['number-of-child'] + 'pax/' + this._breakdown['accommodation']['items'][1].quantity + 'days' + '</td>' + '<td class="text-right">$' + parseFloat(this._breakdown['accommodation']['items'][1].amount).toFixed(2) + '</td>' + '</tr>' + '<tr><td colspan="2" class="subtotal">Subtotal: <span>$' + parseFloat((this._breakdown['accommodation']['items'][0].amount + this._breakdown['accommodation']['items'][1].amount) + '').toFixed(2) + '</span></td></tr></tbody>' + '</table>';
        //Update breakdown summary
        this._breakdownSummary.accommodation = this._breakdown['accommodation']['items'];
        //MEALS
        var _tbl = '';
        if (typeof this._breakdown['meals'] === 'undefined') {
            this._breakdown['meals'] = { items: [] };
        }
        var mealAdultTotal = 0;
        var mealChildTotal = 0;
        var mealQtyAdults = 0;
        var mealQtyChild = 0;
        for (var m = 0; m < this._breakdown['meals'].items.length; m++) {
            //_tbl+='<tr><td colspan="2"><strong>'+this._breakdown['meals'].items[m]['text']+'</strong></td></tr>'
            //_tbl+='<tr><td>'+this._breakdown['meals'].items[m].items[0]['text']+'</td><td class="text-right">$'+parseFloat(this._breakdown['meals'].items[m].items[0]['amount']).toFixed(2)+'</td></tr>'
            //_tbl+='<tr><td>'+this._breakdown['meals'].items[m].items[1]['text']+'</td><td class="text-right">$'+parseFloat(this._breakdown['meals'].items[m].items[1]['amount']).toFixed(2)+'</td></tr>'
            mealAdultTotal += this._breakdown['meals'].items[m].items[0]['amount'];
            mealQtyAdults += this._breakdown['meals'].items[m].items[0].quantity;
            mealChildTotal += this._breakdown['meals'].items[m].items[1]['amount'];
            mealQtyChild += this._breakdown['meals'].items[m].items[1].quantity;
        }
        this._breakdownSummary.meals = {
            adults: { quantity: mealQtyAdults, amount: mealAdultTotal },
            child: { quantity: mealQtyChild, amount: mealChildTotal }
        };
        _tbl += '<tr><td>Adults @ ' + mealQtyAdults + ' meal(s)</td><td class="text-right">$' + parseFloat(mealAdultTotal + '').toFixed(2) + '</td></tr>';
        _tbl += '<tr><td>Child @ ' + mealQtyChild + ' meal(s)</td><td class="text-right">$' + parseFloat(mealChildTotal + '').toFixed(2) + '</td></tr>';
        _tbl += '<tr><td colspan="2" class="subtotal">Subtotal: <span>$' + parseFloat((mealAdultTotal + mealChildTotal) + '').toFixed(2) + '</span></td></tr>';
        tmpTables += '<table class="scc-table">' + '<thead>' + '<tr>' + '<th colspan="2">Meals</th>' + '</tr>' + '</thead>' + '<tbody>' + _tbl + '</tbody>' + '</table>';
        //ACTIVITIES
        _tbl = '';
        if (typeof this._breakdown['activities'] === 'undefined') {
            this._breakdown['activities'] = { items: [] };
        }
        var activityTotalAmount = 0;
        this._breakdownSummary.activities = [];
        for (var m = 0; m < this._breakdown['activities'].items.length; m++) {
            _tbl += '<tr>' +
                '<td>' + this._breakdown['activities'].items[m]['text'] + '</td>' +
                '<td class="text-right">$' + parseFloat(this._breakdown['activities'].items[m]['amount']).toFixed(2) + '</td>' +
                '</tr>';
            this._breakdownSummary.activities.push({ activity: this._breakdown['activities'].items[m]['text'], amount: this._breakdown['activities'].items[m]['amount'] });
            activityTotalAmount += this._breakdown['activities'].items[m]['amount'];
        }
        _tbl += '<tr><td colspan="2" class="subtotal">Subtotal: <span>$' + parseFloat(activityTotalAmount + '').toFixed(2) + '</span></td></tr>';
        tmpTables += '<table class="scc-table">' + '<thead>' + '<tr>' + '<th colspan="2">Activities</th>' + '</tr>' + '</thead>' + '<tbody>' + _tbl + '</tbody>' + '</table>';
        $(breakdownView).append('<div class="col-100p">' + tmpTables + '</div>');
        $(breakdownView).append('<div class="main-price-total">TOTAL: <span>$' + parseFloat(this._total + '').toFixed(2) + '</span></div><br>');
        console.log("BREAKDOWN");
        console.log(this._breakdown);
        //console.log(this._breakdownSummary);
    };
    /*------------------------
        Submit Fields
    ------------------------*/
    SCC_Calculator.prototype.submitFields = function () {
        var tmpData = {
            info: this._fields,
            items: this._breakdownSummary
        };
        $.ajax({
            url: this._endpoint,
            type: "post",
            data: tmpData,
            complete: function () {
                alert('success');
            }
        });
    };
    return SCC_Calculator;
}());
jQuery(document).ready(function ($) {
    //temporary
    var priceList = {
        accommodation: {
            adults: 22.00,
            others: 22.00
        },
        meals: [
            {
                text: 'Breakfast',
                name: 'breakfast',
                price: {
                    adults: 17.25,
                    others: 14.50
                }
            },
            {
                text: 'A/Tea',
                name: 'atea',
                price: {
                    adults: 3.50,
                    others: 3.50
                }
            },
            {
                text: 'Lunch',
                name: 'lunch',
                price: {
                    adults: 17.25,
                    others: 14.50
                }
            },
            {
                text: 'Snacks',
                name: 'snacks',
                price: {
                    adults: 3.50,
                    others: 3.50
                }
            },
            {
                text: 'Dinner',
                name: 'dinner',
                price: {
                    adults: 17.25,
                    others: 14.50
                }
            },
            {
                text: 'Supper',
                name: 'supper',
                price: {
                    adults: 17.25,
                    others: 14.50
                }
            }
        ],
        activities: [
            {
                text: 'Camp Out & Cook Out',
                name: 'camp-out-cook-out',
                category: 'leadership',
                ageGroup: {
                    min: 5,
                    max: null
                },
                price: {
                    default: 55
                },
            },
            {
                text: 'Trust Initiatives',
                name: 'trust-initiatives',
                category: 'leadership',
                ageGroup: {
                    min: 6,
                    max: null
                },
                price: {
                    default: 16
                }
            },
            {
                text: 'Hoop Pine Climb',
                name: 'hoop-pint-climb',
                category: 'high-adventure',
                ageGroup: {
                    min: 6,
                    max: null
                },
                price: {
                    adults: 35,
                    others: 20
                }
            },
            {
                text: 'Survivor!!!',
                name: 'survivor',
                category: 'ground-adventure',
                ageGroup: {
                    min: 5,
                    max: null
                },
                price: {
                    default: 16
                }
            },
            {
                text: 'The Great Escape',
                name: 'the-great-escape',
                category: 'ground-adventure',
                ageGroup: {
                    min: 4,
                    max: null
                },
                price: {
                    default: 18
                }
            },
            {
                text: 'The Island',
                name: 'the-island',
                category: 'ground-adventure',
                ageGroup: {
                    min: 3,
                    max: 9
                },
                price: {
                    default: 16
                }
            },
            {
                text: 'Jungle Fever',
                name: 'jungle-fever',
                category: 'ground-adventure',
                ageGroup: {
                    min: null,
                    max: 6
                },
                price: {
                    default: 16
                }
            },
            {
                text: 'Team Challenge',
                name: 'team-challenge',
                category: 'team-initiative-activities',
                ageGroup: {
                    min: null,
                    max: null
                },
                price: {
                    default: 16
                }
            },
            {
                text: 'Team Building',
                name: 'team-building',
                category: 'team-initiative-activities',
                ageGroup: {
                    min: null,
                    max: null
                },
                price: {
                    default: 16
                }
            },
            {
                text: 'Wilderness Skills',
                name: 'wilderness-skills',
                category: 'team-initiative-activities',
                ageGroup: {
                    min: 5,
                    max: null
                },
                price: {
                    default: 16
                }
            },
            {
                text: 'Scavenger Hunt',
                name: 'scavenger-hunt',
                category: 'exploration',
                ageGroup: {
                    min: 3,
                    max: 7
                },
                price: {
                    default: 13
                }
            },
            {
                text: 'Nature Walk',
                name: 'nature-walk',
                category: 'exploration',
                ageGroup: {
                    min: null,
                    max: null
                },
                price: {
                    default: 13
                }
            }
        ]
    };
    var questions = {
        meals: {
            headline: null,
            subheadline: null,
            question: 'Please choose your first meal',
            priceList: priceList.meals
        },
        ageGroup: {
            headline: null,
            subheadline: null,
            question: 'Choice of age groups',
        },
        activities: {
            headline: null,
            subheadline: null,
            question: 'Select activities',
            priceList: priceList.activities
        }
    };
    var scc = new SCC_Calculator($('.scc-modal-wrapper'));
    scc.registerFieldArray('activities'); //register field activities to support multiple answers
    scc.registerPriceList(priceList);
    scc.registerEndpointURL('/scc/v1');
    scc.init();
    // $('.scc-modal-wrapper .scc-modal-inner').each(function(index,element){
    // };
    var dateToday = new Date();
    $("input.scc-date").datepicker({
        inline: true,
        minDate: dateToday,
    });
    $("button.scc-modal-trigger").on('click', function (e) {
        e.preventDefault();
        $(this).next().fadeIn();
        scc.initializeHeight();
        $('body').addClass('scc-modal-fixed');
    });
    $('.scc-modal-close').on('click', function (e) {
        e.preventDefault();
        $(this).closest('.scc-modal-wrapper').fadeOut();
        $('body').removeClass('scc-modal-fixed');
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2NjLXNjcmlwdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNjYy1zY3JpcHQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7O0VBS0U7QUFNRjtJQVVJLHdCQUFvQixZQUFnQjtRQUFoQixpQkFBWSxHQUFaLFlBQVksQ0FBSTtRQVA1QixpQkFBWSxHQUFhLEVBQUUsQ0FBQztRQUc1QixXQUFNLEdBQVUsSUFBSSxDQUFDO1FBQ3JCLGNBQVMsR0FBRyxFQUFFLENBQUM7UUFJbkIsQ0FBQyxHQUFDLE1BQU0sQ0FBQztRQUVULElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBQ00sNENBQW1CLEdBQTFCLFVBQTJCLEdBQVU7UUFDakMsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7SUFDekIsQ0FBQztJQUVNLDBDQUFpQixHQUF4QixVQUF5QixFQUFFO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBRWxDLEdBQUcsQ0FBQSxDQUFDLElBQUksR0FBRyxJQUFJLEVBQUUsQ0FBQyxDQUFBLENBQUM7WUFFZixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUUxQixFQUFFLENBQUEsQ0FBQyxHQUFHLEtBQUssZUFBZSxDQUFDLENBQzNCLENBQUM7Z0JBQ0csSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDbkMsQ0FBQztZQUNELElBQUksQ0FDSixDQUFDO2dCQUNHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUN6QixHQUFHLENBQUEsQ0FBQyxJQUFJLENBQUMsR0FBUSxDQUFDLEVBQUMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxFQUFFLEVBQUMsQ0FBQzt3QkFDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3RELElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUMxRCxDQUFDO2dCQUNMLENBQUM7WUFDTCxDQUFDO1FBQ0wsQ0FBQztRQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFFTSwyQ0FBa0IsR0FBekIsVUFBMEIsSUFBWTtRQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRU0seUNBQWdCLEdBQXZCO1FBQ0ksSUFBSSxZQUFZLEdBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVMsS0FBSyxFQUFDLE9BQU87WUFDckUsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBRXpDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxpREFBaUQ7WUFFakYsRUFBRSxDQUFBLENBQUMsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUEsQ0FBQztnQkFDL0MsSUFBSSxTQUFTLEdBQVUsWUFBWSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUMsV0FBVyxFQUFFLEdBQUcsRUFBRSxDQUFDLDJCQUEyQixDQUFDO2dCQUMvSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLDBCQUEwQixDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzlGLENBQUM7WUFFRCxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUEsa0RBQWtEO1FBQ3hGLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVNLDZCQUFJLEdBQVg7UUFDSSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUM7UUFDZixJQUFJLFdBQVcsR0FBVSxDQUFDLENBQUM7UUFDM0IsSUFBSSxXQUFXLEdBQU8sSUFBSSxDQUFDO1FBRTNCLG9EQUFvRDtRQUVwRDs7MENBRWtDO1FBQ2xDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBRXhCLDJDQUEyQztRQUMzQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFTLEtBQUssRUFBQyxPQUFPO1lBRXhGLG1CQUFtQjtZQUNuQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUMsVUFBUyxDQUFDO2dCQUM5QyxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBRW5CLDJCQUEyQjtnQkFDM0IsRUFBRSxDQUFBLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLFlBQVksQ0FBQyxDQUFBLENBQUM7b0JBQzVFLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztnQkFDaEMsQ0FBQztnQkFFRCxJQUFJLEtBQUssR0FBVyxHQUFHLENBQUMsY0FBYyxDQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO2dCQUUxRyxFQUFFLENBQUEsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUEsQ0FBQztvQkFDcEYsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDcEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBRWpILG1CQUFtQjtvQkFFbkIsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztvQkFFNUQseUNBQXlDO29CQUN6QyxFQUFFLENBQUEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLFlBQVksQ0FBQyxDQUNoSSxDQUFDO3dCQUNHLElBQUksZUFBZSxHQUFVLEVBQUUsQ0FBQzt3QkFDaEMsR0FBRyxDQUFBLENBQUMsSUFBSSxXQUFXLElBQUksR0FBRyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUNwRCxDQUFDOzRCQUNHLDJCQUEyQjs0QkFDM0IsRUFBRSxDQUFBLENBQUMsT0FBTyxXQUFXLEtBQUssV0FBVyxDQUFDLENBQ3RDLENBQUM7Z0NBQ0csSUFBSSxXQUFXLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztnQ0FDNUQsSUFBSSxRQUFRLEdBQUc7b0NBQ1gsUUFBUSxFQUFDO3dDQUNMLEdBQUcsRUFBRSxDQUFDO3dDQUNOLEdBQUcsRUFBQyxDQUFDO3FDQUNSO29DQUNELGVBQWUsRUFBQzt3Q0FDWixHQUFHLEVBQUMsQ0FBQzt3Q0FDTCxHQUFHLEVBQUMsQ0FBQztxQ0FDUjtvQ0FDRCxRQUFRLEVBQUM7d0NBQ0wsR0FBRyxFQUFDLEVBQUU7d0NBQ04sR0FBRyxFQUFDLEdBQUc7cUNBQ1Y7aUNBQ0osQ0FBQztnQ0FDRixJQUFJLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0NBQ3BCLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUVyRCxFQUFFLENBQUEsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBSSxJQUFJLElBQUksV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUUsSUFBSSxDQUFDLENBQUEsQ0FBQztvQ0FDbkUsT0FBTyxHQUFHLElBQUksQ0FBQztnQ0FDbkIsQ0FBQztnQ0FDRCxJQUFJLENBQUMsRUFBRSxDQUFBLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUksSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUUsZUFBZSxDQUFDLEdBQUcsQ0FBRSxDQUFDLENBQzdGLENBQUM7b0NBQ0csT0FBTyxHQUFHLElBQUksQ0FBQztnQ0FDbkIsQ0FBQztnQ0FDRCxJQUFJLENBQUMsRUFBRSxDQUFBLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFFLElBQUksQ0FBQyxDQUM5RixDQUFDO29DQUNHLE9BQU8sR0FBRyxJQUFJLENBQUM7Z0NBQ25CLENBQUM7Z0NBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLGVBQWUsQ0FBQyxHQUFHLElBQUksV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUksZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUMzRyxDQUFDO29DQUNHLE9BQU8sR0FBRyxJQUFJLENBQUM7Z0NBQ25CLENBQUM7Z0NBQ0QsSUFBSSxRQUFRLEdBQUcsQ0FBQyxPQUFPLFdBQVcsQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLFdBQVcsQ0FBQyxDQUFBLENBQUMsQ0FBQSxXQUFXLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQSxDQUFDLENBQUEsV0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0NBQ3JILEVBQUUsQ0FBQSxDQUFDLE9BQU8sQ0FBQyxDQUNYLENBQUM7b0NBQ0csZUFBZSxJQUFJLHVCQUF1Qjt3Q0FDMUIseUtBQXlLO3dDQUNySyxxQ0FBcUMsR0FBQyxXQUFXLENBQUMsSUFBSSxHQUFDLFVBQVU7d0NBQ2pFLHNDQUFzQyxHQUFDLFFBQVEsR0FBQyxTQUFTO3dDQUN6RCxpRUFBaUUsR0FBQyxXQUFXLENBQUMsSUFBSSxHQUFDLE1BQU07d0NBQzdGLFFBQVE7d0NBQ1osUUFBUSxDQUFDO2dDQUd6QixDQUFDOzRCQUVMLENBQUM7d0JBQ0wsQ0FBQzt3QkFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQzt3QkFDOUksR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUM7d0JBQ3ZCLEdBQUcsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO29CQUNqQyxDQUFDO29CQUNELENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVMsS0FBSyxFQUFDLE9BQU87d0JBQ3JGLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztvQkFDckQsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsaUJBQWlCO2dCQUNyQixDQUFDO2dCQUNELElBQUksQ0FDSixDQUFDO29CQUNHLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDdkIsQ0FBQztnQkFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFdBQVc7Z0JBQ3JDLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUM3QixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM3QixDQUFDLENBQUMsQ0FBQztZQUVILDZCQUE2QjtZQUM3QixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUMsVUFBUyxDQUFDO2dCQUM5QyxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQ25CLEVBQUUsQ0FBQSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQSxDQUFDO29CQUNWLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUE7b0JBQ25FLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsS0FBSyxHQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFBO2dCQUNwSCxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx3Q0FBd0M7SUFDeEMsd0NBQXdDO0lBQ3hDLHdDQUF3QztJQUNoQywrQ0FBc0IsR0FBOUI7UUFDSSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUM7UUFDZixDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUMsVUFBUyxDQUFDO1lBQzdELENBQUMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ2hDLEVBQUUsQ0FBQSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQSxDQUFDO2dCQUM3QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNsRCxDQUFDO1lBQ0QsSUFBSSxDQUFBLENBQUM7Z0JBQ0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDL0MsQ0FBQztZQUVELEVBQUUsQ0FBQSxDQUFDLE9BQU8sR0FBRyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUEsQ0FBQztnQkFDMUQsR0FBRyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO2dCQUN4QyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7WUFDaEMsQ0FBQztZQUVELElBQUksS0FBSyxHQUFXLEdBQUcsQ0FBQyxjQUFjLENBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7WUFDdkcsRUFBRSxDQUFBLENBQUMsS0FBSyxDQUFDLENBQUEsQ0FBQztnQkFDTixHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO2dCQUN6RCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztZQUM3RixDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU0sd0NBQWUsR0FBdEIsVUFBdUIsT0FBVztRQUM5QixJQUFJLEdBQUcsR0FBVSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFBQSxDQUFDO1FBRXBELEVBQUUsQ0FBQSxDQUFDLEdBQUcsSUFBRyxTQUFTLElBQUksR0FBRyxLQUFJLFVBQVUsQ0FBQyxDQUN4QyxDQUFDO1lBQ0csRUFBRSxDQUFBLENBQUMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFdBQVcsQ0FBQyxDQUMvQyxDQUFDO2dCQUNHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQzlCLENBQUM7UUFDTCxDQUFDO1FBRUQsSUFBSSxPQUFPLEdBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO1FBQ3RELElBQUksU0FBUyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO1FBQ3pELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLEdBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBRSxrQkFBa0I7UUFFbkgsSUFBSSxTQUFTLEdBQVUsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO1FBQ2xFLElBQUksUUFBUSxHQUFVLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztRQUVoRSxFQUFFLENBQUEsQ0FBQyxHQUFHLEtBQUcsZUFBZSxDQUFDLENBQ3pCLENBQUM7WUFDRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztnQkFDcEI7b0JBQ0ksSUFBSSxFQUFDLEdBQUc7b0JBQ1IsS0FBSyxFQUFDO3dCQUNGOzRCQUNJLElBQUksRUFBQyxRQUFROzRCQUNiLFFBQVEsRUFBRSxJQUFJOzRCQUNkLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLFNBQVM7eUJBQ2xFO3dCQUNEOzRCQUNJLElBQUksRUFBQyxPQUFPOzRCQUNaLFFBQVEsRUFBRSxJQUFJOzRCQUNkLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLFFBQVE7eUJBQ2pFO3FCQUNKO2lCQUNKLENBQUM7UUFDTixDQUFDO1FBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQSxDQUFDLEdBQUcsS0FBRyxVQUFVLENBQUMsQ0FDekIsQ0FBQztZQUNHLElBQUksWUFBWSxHQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUM3RSxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsR0FBRyxZQUFZLENBQUMsQ0FBQztZQUMzQyxJQUFJLE9BQU8sR0FBRyxPQUFPLENBQUM7WUFDdEIsSUFBSSxjQUFjLEdBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUN4RSxJQUFJLFNBQVMsR0FBUyxFQUFFLENBQUM7WUFDekIsSUFBSSxTQUFTLEdBQVMsRUFBRSxDQUFDO1lBQ3pCLEdBQUcsQ0FBQSxDQUFDLElBQUksQ0FBQyxHQUFVLENBQUMsRUFBQyxDQUFDLElBQUksSUFBSSxFQUFDLENBQUMsRUFBRSxFQUNsQyxDQUFDO2dCQUNHLEdBQUcsQ0FBQSxDQUFDLElBQUksQ0FBQyxHQUFRLGNBQWMsRUFBRSxDQUFDLEdBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQ3BGLENBQUM7b0JBRUcsY0FBYyxHQUFHLENBQUMsQ0FBQyxDQUFDLDBCQUEwQjtvQkFDOUMsSUFBSSxXQUFXLEdBQVcsS0FBSyxDQUFDO29CQUNoQyxFQUFFLENBQUEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsWUFBWSxDQUFDLENBQUMsQ0FDckMsQ0FBQzt3QkFDRyxXQUFXLEdBQUcsSUFBSSxDQUFDO29CQUN2QixDQUFDO29CQUVELEVBQUUsQ0FBQSxDQUFDLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQSxDQUFDO3dCQUNyQixFQUFFLENBQUEsQ0FBQyxPQUFPLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FBQSxDQUFDOzRCQUNwQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBQyxLQUFLLEVBQUMsQ0FBRyxFQUFDLElBQUksRUFBQyxRQUFRLEVBQUMsUUFBUSxFQUFDLENBQUMsRUFBQyxNQUFNLEVBQUMsQ0FBQyxFQUFDLEVBQUUsRUFBQyxJQUFJLEVBQUMsT0FBTyxFQUFDLFFBQVEsRUFBQyxDQUFDLEVBQUMsTUFBTSxFQUFDLENBQUMsRUFBQyxDQUFHLEVBQUMsQ0FBQzt3QkFDL0osQ0FBQzt3QkFDRCxRQUFRO3dCQUNSLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQzFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxXQUFXLEdBQUMsU0FBUyxHQUFHLE1BQU0sR0FBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUMsU0FBUyxDQUFDO3dCQUNsSCxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDdEwsT0FBTzt3QkFDUCxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUMxQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsVUFBVSxHQUFDLFFBQVEsR0FBRyxNQUFNLEdBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFDLFNBQVMsQ0FBQzt3QkFDaEgsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQzVMLENBQUM7Z0JBQ0YsQ0FBQztZQUVMLENBQUM7WUFFRCxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUMsU0FBUyxDQUFDLENBQUM7WUFFakQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsR0FBRztnQkFDdkIsSUFBSSxFQUFDLE9BQU87Z0JBQ1osS0FBSyxFQUFDLFNBQVM7YUFDbEIsQ0FBQztRQUVOLENBQUM7UUFDRCxJQUFJLENBQUMsRUFBRSxDQUFBLENBQUMsR0FBRyxLQUFHLGNBQWMsQ0FBQyxDQUM3QixDQUFDO1lBQ0csSUFBSSxjQUFjLEdBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUNwRSxJQUFJLFNBQVMsR0FBUyxFQUFFLENBQUM7WUFDekIsSUFBSSxTQUFTLEdBQVMsRUFBRSxDQUFDO1lBQ3pCLEdBQUcsQ0FBQSxDQUFDLElBQUksQ0FBQyxHQUFVLENBQUMsRUFBQyxDQUFDLEdBQUcsSUFBSSxFQUFDLENBQUMsRUFBRSxFQUNqQyxDQUFDO2dCQUNHLEdBQUcsQ0FBQSxDQUFDLElBQUksQ0FBQyxHQUFRLGNBQWMsRUFBRSxDQUFDLEdBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQ3BGLENBQUM7b0JBRUcsY0FBYyxHQUFHLENBQUMsQ0FBQyxDQUFDLDBCQUEwQjtvQkFDOUMsRUFBRSxDQUFBLENBQUMsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxDQUFDLENBQUEsQ0FBQzt3QkFDcEMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUMsS0FBSyxFQUFDLENBQUcsRUFBQyxJQUFJLEVBQUMsUUFBUSxFQUFDLFFBQVEsRUFBQyxDQUFDLEVBQUMsTUFBTSxFQUFDLENBQUMsRUFBQyxFQUFFLEVBQUMsSUFBSSxFQUFDLE9BQU8sRUFBQyxRQUFRLEVBQUMsQ0FBQyxFQUFDLE1BQU0sRUFBQyxDQUFDLEVBQUMsQ0FBRyxFQUFDLENBQUM7b0JBQy9KLENBQUM7b0JBQ0QsUUFBUTtvQkFDUixTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMxQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsV0FBVyxHQUFDLFNBQVMsR0FBRyxNQUFNLEdBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFDLE1BQU0sQ0FBQztvQkFDL0csU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ2xMLE9BQU87b0JBQ1AsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDMUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFVBQVUsR0FBQyxRQUFRLEdBQUcsTUFBTSxHQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBQyxNQUFNLENBQUM7b0JBQzdHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNyTCxDQUFDO2dCQUNELFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBQyxTQUFTLENBQUMsQ0FBQztZQUNyRCxDQUFDO1lBRUQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRztnQkFDbkIsSUFBSSxFQUFDLEdBQUc7Z0JBQ1IsS0FBSyxFQUFDLFNBQVM7YUFDbEIsQ0FBQztRQUdOLENBQUM7UUFDRCxJQUFJLENBQUMsRUFBRSxDQUFBLENBQUMsR0FBRyxLQUFHLFlBQVksQ0FBQyxDQUMzQixDQUFDO1lBQ0csSUFBSSxhQUFhLEdBQVMsRUFBRSxDQUFDO1lBQzdCLEdBQUcsQ0FBQSxDQUFDLElBQUksQ0FBQyxHQUFVLENBQUMsRUFBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFDLENBQUMsRUFBRSxFQUMzRCxDQUFDO2dCQUNHLElBQUksUUFBUSxHQUFHLENBQ1gsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssV0FBVyxDQUFDLENBQUEsQ0FBQztvQkFDdEcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFBLENBQUM7b0JBQzdFLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFFbEYsSUFBSSxRQUFRLEdBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9HLGFBQWEsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFDLElBQUksRUFBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUMsS0FBSyxHQUFDLFFBQVEsR0FBQyxLQUFLLEVBQUMsTUFBTSxFQUFFLFFBQVEsR0FBRyxRQUFRLEVBQUMsQ0FBQztZQUNqSixDQUFDO1lBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRztnQkFDbkIsSUFBSSxFQUFDLEdBQUc7Z0JBQ1IsS0FBSyxFQUFDLGFBQWE7YUFDdEIsQ0FBQztRQUNOLENBQUM7UUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQzVCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUloQixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztJQUUvQixDQUFDO0lBRUQsbUJBQW1CO0lBQ25COzs0Q0FFd0M7SUFDaEMsbUNBQVUsR0FBbEIsVUFBbUIsV0FBZSxFQUFDLElBQVU7UUFFekMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDbkMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNsQixDQUFDLEVBQUUsQ0FBQztZQUNSLENBQUM7UUFDTCxDQUFDO1FBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRU8scUNBQVksR0FBcEIsVUFBcUIsS0FBUztRQUMxQixJQUFJLEdBQUcsR0FBVSxLQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTVDLDhEQUE4RDtRQUM5RCxFQUFFLENBQUEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FDdEMsQ0FBQztZQUNHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUNwQyxDQUFDO1FBQ0QsSUFBSSxDQUNKLENBQUM7WUFDRyxtRkFBbUY7WUFDbkYsRUFBRSxDQUFBLENBQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFdBQVcsQ0FBQyxDQUFBLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQzNCLENBQUM7WUFFRCx1Q0FBdUM7WUFDdkMsRUFBRSxDQUFBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUNwQyxDQUFDO2dCQUNHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN4QyxDQUFDO1FBQ0wsQ0FBQztRQUNELG1DQUFtQztRQUVwQyxJQUFJO1FBQ0osNEJBQTRCO0lBRS9CLENBQUM7SUFFRDs7NENBRXdDO0lBQ2hDLHVDQUFjLEdBQXRCLFVBQXVCLE1BQVk7UUFDL0IsSUFBSSxHQUFHLEdBQVcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksT0FBTyxHQUFVLEVBQUUsQ0FBQztRQUV4QixHQUFHLENBQUEsQ0FBYyxVQUFNLEVBQU4saUJBQU0sRUFBTixvQkFBTSxFQUFOLElBQU07WUFBbkIsSUFBSSxLQUFLLGVBQUE7WUFDVCxFQUFFLENBQUEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQ3pELENBQUM7Z0JBQ0csRUFBRSxDQUFBLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQzNFLENBQUM7b0JBQ0csQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO29CQUMvQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw4REFBOEQsQ0FBQyxDQUFDO2dCQUMzRyxDQUFDO2dCQUNELEdBQUcsR0FBRyxLQUFLLENBQUM7WUFDaEIsQ0FBQztZQUNELElBQUksQ0FDSixDQUFDO2dCQUNHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsQ0FBQztnQkFDbEQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFFdEUscUJBQXFCO1lBRXpCLENBQUM7WUFFRCx3QkFBd0I7WUFDeEIsRUFBRSxDQUFBLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsS0FBSyxPQUFPLENBQUMsQ0FDMUMsQ0FBQztnQkFDRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsMkpBQTJKLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQ3JMLENBQUM7b0JBQ0csRUFBRSxDQUFBLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQzNFLENBQUM7d0JBQ0csQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO3dCQUMvQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw2REFBNkQsQ0FBQyxDQUFDO29CQUMxRyxDQUFDO29CQUNELEdBQUcsR0FBRyxLQUFLLENBQUM7Z0JBQ2hCLENBQUM7WUFDTCxDQUFDO1lBRUQsc0JBQXNCO1lBQ3RCLElBQUksVUFBVSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDNUMsRUFBRSxDQUFBLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUEsQ0FBQztnQkFDekMsRUFBRTtnQkFDRixJQUFJLFFBQVEsR0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsR0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUV2SCxFQUFFLENBQUEsQ0FBQyxDQUFFLE9BQU8sS0FBSyxVQUFVLENBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFFLENBQUMsQ0FBQSxDQUFDO29CQUNyRCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMvQixPQUFPLEdBQUcsVUFBVSxDQUFDO2dCQUN6QixDQUFDO1lBQ0wsQ0FBQztZQUNELElBQUksQ0FDSixDQUFDO2dCQUNHLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDN0IsQ0FBQztTQUdKO1FBRUQsTUFBTSxDQUFDLEdBQUcsQ0FBQztJQUNmLENBQUM7SUFFRDs7OEJBRTBCO0lBQ2xCLGlDQUFRLEdBQWhCO1FBQ0ksSUFBSSxHQUFHLEdBQVUsQ0FBQyxDQUFDO1FBQ25CLEdBQUcsQ0FBQSxDQUFDLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQSxDQUFDO1lBQzVCLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxTQUFTLENBQUMsQ0FDckIsQ0FBQztnQkFDRyxHQUFHLENBQUEsQ0FBQyxJQUFJLENBQUMsR0FBUSxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBQyxDQUFDLEVBQUUsRUFBQyxDQUFDO29CQUN4RCxFQUFFLENBQUEsQ0FBQyxHQUFHLEtBQUksZUFBZSxDQUFDLENBQUEsQ0FBQzt3QkFDdkIsR0FBRyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztvQkFDaEQsQ0FBQztvQkFDRCxJQUFJLENBQUMsRUFBRSxDQUFBLENBQUMsR0FBRyxLQUFHLE9BQU8sQ0FBQyxDQUN0QixDQUFDO3dCQUNHLEdBQUcsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7b0JBQ3pHLENBQUM7b0JBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQSxDQUFDLEdBQUcsS0FBSyxZQUFZLENBQUMsQ0FDN0IsQ0FBQzt3QkFDRyxHQUFHLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO29CQUNoRCxDQUFDO2dCQUNMLENBQUM7WUFDTCxDQUFDO1FBQ0wsQ0FBQztRQUNELElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ2xCLE1BQU0sQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBQ0Q7OzhCQUUwQjtJQUNsQiw0Q0FBbUIsR0FBM0I7UUFDSSxJQUFJLGFBQWEsR0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQywrREFBK0QsQ0FBQyxDQUFDO1FBRW5ILElBQUksQ0FBQyxpQkFBaUIsR0FBRztZQUNyQixZQUFZLEVBQUMsRUFBRTtZQUNmLE9BQU8sRUFBQyxFQUFFO1lBQ1YsZUFBZSxFQUFDLEVBQUU7U0FDckIsQ0FBQztRQUVGLGdCQUFnQjtRQUNoQixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRTFCLE1BQU07UUFDTixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLDRGQUE0RixHQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFDLHFCQUFxQixDQUFDLENBQUM7UUFDOUosT0FBTztRQUNQLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsNkZBQTZGLEdBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUMscUJBQXFCLENBQUMsQ0FBQztRQUVoSyxxQkFBcUI7UUFDckIsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpRUFBaUUsQ0FBQyxDQUFDO1FBRTNGLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQztRQUduQixlQUFlO1FBQ2YsU0FBUyxJQUFJLDJCQUEyQixHQUFDLFNBQVMsR0FBQyxNQUFNLEdBQUMsb0NBQW9DLEdBQUMsT0FBTyxHQUFDLFVBQVUsR0FBQyxTQUFTLEdBQUMsTUFBTSxHQUFDLE1BQU0sR0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBQyxHQUFHLEdBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxHQUFDLE1BQU0sR0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBQyxNQUFNLEdBQUMsT0FBTyxHQUFDLDBCQUEwQixHQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBQyxPQUFPLEdBQUMsT0FBTyxHQUFDLE1BQU0sR0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUMsR0FBRyxHQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsR0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUMsTUFBTSxHQUFDLE9BQU8sR0FBQywwQkFBMEIsR0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUMsT0FBTyxHQUFDLE9BQU8sR0FBQyx3REFBd0QsR0FBRSxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRSwyQkFBMkIsR0FBQyxVQUFVLENBQUM7UUFDajdCLDBCQUEwQjtRQUMxQixJQUFJLENBQUMsaUJBQWlCLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7UUFHakYsT0FBTztRQUNQLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNkLEVBQUUsQ0FBQSxDQUFDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FDbkQsQ0FBQztZQUNHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBQyxLQUFLLEVBQUMsRUFBRSxFQUFDLENBQUM7UUFDMUMsQ0FBQztRQUVELElBQUksY0FBYyxHQUFHLENBQUMsQ0FBQztRQUN2QixJQUFJLGNBQWMsR0FBRyxDQUFDLENBQUM7UUFDdkIsSUFBSSxhQUFhLEdBQUcsQ0FBQyxDQUFDO1FBQ3RCLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztRQUVyQixHQUFHLENBQUEsQ0FBQyxJQUFJLENBQUMsR0FBUSxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBQyxDQUFDLEVBQUUsRUFBQyxDQUFDO1lBQzVELHNHQUFzRztZQUN0Ryw4TEFBOEw7WUFDOUwsOExBQThMO1lBQzlMLGNBQWMsSUFBSyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDeEUsYUFBYSxJQUFNLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7WUFDdkUsY0FBYyxJQUFLLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4RSxZQUFZLElBQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUMzRSxDQUFDO1FBQ0QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssR0FBRztZQUMzQixNQUFNLEVBQUMsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFLE1BQU0sRUFBRSxjQUFjLEVBQUM7WUFDekQsS0FBSyxFQUFFLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFDO1NBQzNELENBQUM7UUFDRixJQUFJLElBQUUsbUJBQW1CLEdBQUMsYUFBYSxHQUFDLHVDQUF1QyxHQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFDLFlBQVksQ0FBQztRQUN0SSxJQUFJLElBQUUsa0JBQWtCLEdBQUMsWUFBWSxHQUFDLHVDQUF1QyxHQUFDLFVBQVUsQ0FBQyxjQUFjLEdBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFDLFlBQVksQ0FBQztRQUNwSSxJQUFJLElBQUUsd0RBQXdELEdBQUUsVUFBVSxDQUFDLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQyxHQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRSxtQkFBbUIsQ0FBQztRQUNqSixTQUFTLElBQUksMkJBQTJCLEdBQUMsU0FBUyxHQUFDLE1BQU0sR0FBQyw0QkFBNEIsR0FBQyxPQUFPLEdBQUMsVUFBVSxHQUFDLFNBQVMsR0FBQyxJQUFJLEdBQUMsVUFBVSxHQUFDLFVBQVUsQ0FBQztRQUcvSSxZQUFZO1FBQ1osSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNWLEVBQUUsQ0FBQSxDQUFDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FDeEQsQ0FBQztZQUNHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBQyxLQUFLLEVBQUMsRUFBRSxFQUFDLENBQUM7UUFDL0MsQ0FBQztRQUNELElBQUksbUJBQW1CLEdBQUcsQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO1FBQ3ZDLEdBQUcsQ0FBQSxDQUFDLElBQUksQ0FBQyxHQUFRLENBQUMsRUFBQyxDQUFDLEdBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFDLENBQUMsRUFBRSxFQUFDLENBQUM7WUFDakUsSUFBSSxJQUFJLE1BQU07Z0JBQ0YsTUFBTSxHQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFDLE9BQU87Z0JBQzdELDBCQUEwQixHQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBQyxPQUFPO2dCQUM5RyxPQUFPLENBQUM7WUFDaEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBQyxRQUFRLEVBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFDLENBQUMsQ0FBQztZQUM1SixtQkFBbUIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM1RSxDQUFDO1FBQ0QsSUFBSSxJQUFJLHdEQUF3RCxHQUFFLFVBQVUsQ0FBQyxtQkFBbUIsR0FBRyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUUsbUJBQW1CLENBQUM7UUFDdkksU0FBUyxJQUFJLDJCQUEyQixHQUFDLFNBQVMsR0FBQyxNQUFNLEdBQUMsaUNBQWlDLEdBQUMsT0FBTyxHQUFDLFVBQVUsR0FBQyxTQUFTLEdBQUMsSUFBSSxHQUFDLFVBQVUsR0FBQyxVQUFVLENBQUM7UUFFcEosQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsR0FBQyxTQUFTLEdBQUMsUUFBUSxDQUFDLENBQUM7UUFFckUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw4Q0FBOEMsR0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUMsbUJBQW1CLENBQUMsQ0FBQTtRQUdqSSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzdCLHNDQUFzQztJQUMxQyxDQUFDO0lBRUQ7OzhCQUUwQjtJQUNsQixxQ0FBWSxHQUFwQjtRQUVJLElBQUksT0FBTyxHQUFHO1lBQ1gsSUFBSSxFQUFDLElBQUksQ0FBQyxPQUFPO1lBQ2pCLEtBQUssRUFBQyxJQUFJLENBQUMsaUJBQWlCO1NBQzlCLENBQUE7UUFFRCxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ0gsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTO1lBQ25CLElBQUksRUFBRSxNQUFNO1lBQ1osSUFBSSxFQUFDLE9BQU87WUFDWixRQUFRLEVBQUU7Z0JBQ04sS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3JCLENBQUM7U0FDSixDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0wscUJBQUM7QUFBRCxDQUFDLEFBeGxCRCxJQXdsQkM7QUFJRCxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVMsQ0FBQztJQUM3QixXQUFXO0lBR1gsSUFBSSxTQUFTLEdBQUc7UUFDWixhQUFhLEVBQUU7WUFDWCxNQUFNLEVBQUMsS0FBSztZQUNaLE1BQU0sRUFBQyxLQUFLO1NBQ2Y7UUFDRCxLQUFLLEVBQUM7WUFDRjtnQkFDSSxJQUFJLEVBQUMsV0FBVztnQkFDaEIsSUFBSSxFQUFDLFdBQVc7Z0JBQ2hCLEtBQUssRUFBQztvQkFDRixNQUFNLEVBQUUsS0FBSztvQkFDYixNQUFNLEVBQUUsS0FBSztpQkFDaEI7YUFDSjtZQUNEO2dCQUNJLElBQUksRUFBQyxPQUFPO2dCQUNaLElBQUksRUFBQyxNQUFNO2dCQUNYLEtBQUssRUFBQztvQkFDRixNQUFNLEVBQUMsSUFBSTtvQkFDWCxNQUFNLEVBQUMsSUFBSTtpQkFDZDthQUNKO1lBQ0Q7Z0JBQ0ksSUFBSSxFQUFDLE9BQU87Z0JBQ1osSUFBSSxFQUFDLE9BQU87Z0JBQ1osS0FBSyxFQUFDO29CQUNGLE1BQU0sRUFBQyxLQUFLO29CQUNaLE1BQU0sRUFBQyxLQUFLO2lCQUNmO2FBQ0o7WUFDRDtnQkFDSSxJQUFJLEVBQUMsUUFBUTtnQkFDYixJQUFJLEVBQUMsUUFBUTtnQkFDYixLQUFLLEVBQUM7b0JBQ0YsTUFBTSxFQUFDLElBQUk7b0JBQ1gsTUFBTSxFQUFDLElBQUk7aUJBQ2Q7YUFDSjtZQUNEO2dCQUNJLElBQUksRUFBQyxRQUFRO2dCQUNiLElBQUksRUFBQyxRQUFRO2dCQUNiLEtBQUssRUFBQztvQkFDRixNQUFNLEVBQUMsS0FBSztvQkFDWixNQUFNLEVBQUMsS0FBSztpQkFDZjthQUNKO1lBQ0Q7Z0JBQ0ksSUFBSSxFQUFDLFFBQVE7Z0JBQ2IsSUFBSSxFQUFDLFFBQVE7Z0JBQ2IsS0FBSyxFQUFDO29CQUNGLE1BQU0sRUFBQyxLQUFLO29CQUNaLE1BQU0sRUFBQyxLQUFLO2lCQUNmO2FBQ0o7U0FDSjtRQUNELFVBQVUsRUFBQztZQUNQO2dCQUNJLElBQUksRUFBQyxxQkFBcUI7Z0JBQzFCLElBQUksRUFBQyxtQkFBbUI7Z0JBQ3hCLFFBQVEsRUFBQyxZQUFZO2dCQUNyQixRQUFRLEVBQUM7b0JBQ0wsR0FBRyxFQUFDLENBQUM7b0JBQ0wsR0FBRyxFQUFDLElBQUk7aUJBQ1g7Z0JBQ0QsS0FBSyxFQUFDO29CQUNGLE9BQU8sRUFBQyxFQUFFO2lCQUNiO2FBRUo7WUFDRDtnQkFDSSxJQUFJLEVBQUMsbUJBQW1CO2dCQUN4QixJQUFJLEVBQUMsbUJBQW1CO2dCQUN4QixRQUFRLEVBQUMsWUFBWTtnQkFDckIsUUFBUSxFQUFDO29CQUNMLEdBQUcsRUFBQyxDQUFDO29CQUNMLEdBQUcsRUFBQyxJQUFJO2lCQUNYO2dCQUNELEtBQUssRUFBRTtvQkFDSCxPQUFPLEVBQUMsRUFBRTtpQkFDYjthQUNKO1lBQ0Q7Z0JBQ0ksSUFBSSxFQUFDLGlCQUFpQjtnQkFDdEIsSUFBSSxFQUFDLGlCQUFpQjtnQkFDdEIsUUFBUSxFQUFDLGdCQUFnQjtnQkFDekIsUUFBUSxFQUFDO29CQUNMLEdBQUcsRUFBQyxDQUFDO29CQUNMLEdBQUcsRUFBQyxJQUFJO2lCQUNYO2dCQUNELEtBQUssRUFBQztvQkFDRixNQUFNLEVBQUMsRUFBRTtvQkFDVCxNQUFNLEVBQUMsRUFBRTtpQkFDWjthQUNKO1lBQ0Q7Z0JBQ0ksSUFBSSxFQUFDLGFBQWE7Z0JBQ2xCLElBQUksRUFBQyxVQUFVO2dCQUNmLFFBQVEsRUFBQyxrQkFBa0I7Z0JBQzNCLFFBQVEsRUFBQztvQkFDTCxHQUFHLEVBQUMsQ0FBQztvQkFDTCxHQUFHLEVBQUMsSUFBSTtpQkFDWDtnQkFDRCxLQUFLLEVBQUM7b0JBQ0YsT0FBTyxFQUFDLEVBQUU7aUJBQ2I7YUFDSjtZQUNEO2dCQUNJLElBQUksRUFBQyxrQkFBa0I7Z0JBQ3ZCLElBQUksRUFBQyxrQkFBa0I7Z0JBQ3ZCLFFBQVEsRUFBQyxrQkFBa0I7Z0JBQzNCLFFBQVEsRUFBQztvQkFDTCxHQUFHLEVBQUMsQ0FBQztvQkFDTCxHQUFHLEVBQUMsSUFBSTtpQkFDWDtnQkFDRCxLQUFLLEVBQUM7b0JBQ0YsT0FBTyxFQUFDLEVBQUU7aUJBQ2I7YUFDSjtZQUNEO2dCQUNJLElBQUksRUFBQyxZQUFZO2dCQUNqQixJQUFJLEVBQUMsWUFBWTtnQkFDakIsUUFBUSxFQUFDLGtCQUFrQjtnQkFDM0IsUUFBUSxFQUFDO29CQUNMLEdBQUcsRUFBQyxDQUFDO29CQUNMLEdBQUcsRUFBQyxDQUFDO2lCQUNSO2dCQUNELEtBQUssRUFBQztvQkFDRixPQUFPLEVBQUMsRUFBRTtpQkFDYjthQUNKO1lBQ0Q7Z0JBQ0ksSUFBSSxFQUFDLGNBQWM7Z0JBQ25CLElBQUksRUFBQyxjQUFjO2dCQUNuQixRQUFRLEVBQUMsa0JBQWtCO2dCQUMzQixRQUFRLEVBQUM7b0JBQ0wsR0FBRyxFQUFDLElBQUk7b0JBQ1IsR0FBRyxFQUFDLENBQUM7aUJBQ1I7Z0JBQ0QsS0FBSyxFQUFDO29CQUNGLE9BQU8sRUFBQyxFQUFFO2lCQUNiO2FBQ0o7WUFDRDtnQkFDSSxJQUFJLEVBQUMsZ0JBQWdCO2dCQUNyQixJQUFJLEVBQUMsZ0JBQWdCO2dCQUNyQixRQUFRLEVBQUMsNEJBQTRCO2dCQUNyQyxRQUFRLEVBQUM7b0JBQ0wsR0FBRyxFQUFDLElBQUk7b0JBQ1IsR0FBRyxFQUFDLElBQUk7aUJBQ1g7Z0JBQ0QsS0FBSyxFQUFDO29CQUNGLE9BQU8sRUFBQyxFQUFFO2lCQUNiO2FBQ0o7WUFDRDtnQkFDSSxJQUFJLEVBQUMsZUFBZTtnQkFDcEIsSUFBSSxFQUFDLGVBQWU7Z0JBQ3BCLFFBQVEsRUFBQyw0QkFBNEI7Z0JBQ3JDLFFBQVEsRUFBQztvQkFDTCxHQUFHLEVBQUMsSUFBSTtvQkFDUixHQUFHLEVBQUMsSUFBSTtpQkFDWDtnQkFDRCxLQUFLLEVBQUM7b0JBQ0YsT0FBTyxFQUFDLEVBQUU7aUJBQ2I7YUFDSjtZQUNEO2dCQUNJLElBQUksRUFBQyxtQkFBbUI7Z0JBQ3hCLElBQUksRUFBQyxtQkFBbUI7Z0JBQ3hCLFFBQVEsRUFBQyw0QkFBNEI7Z0JBQ3JDLFFBQVEsRUFBQztvQkFDTCxHQUFHLEVBQUMsQ0FBQztvQkFDTCxHQUFHLEVBQUMsSUFBSTtpQkFDWDtnQkFDRCxLQUFLLEVBQUM7b0JBQ0YsT0FBTyxFQUFDLEVBQUU7aUJBQ2I7YUFDSjtZQUNEO2dCQUNJLElBQUksRUFBQyxnQkFBZ0I7Z0JBQ3JCLElBQUksRUFBQyxnQkFBZ0I7Z0JBQ3JCLFFBQVEsRUFBQyxhQUFhO2dCQUN0QixRQUFRLEVBQUM7b0JBQ0wsR0FBRyxFQUFDLENBQUM7b0JBQ0wsR0FBRyxFQUFDLENBQUM7aUJBQ1I7Z0JBQ0QsS0FBSyxFQUFDO29CQUNGLE9BQU8sRUFBQyxFQUFFO2lCQUNiO2FBQ0o7WUFDRDtnQkFDSSxJQUFJLEVBQUMsYUFBYTtnQkFDbEIsSUFBSSxFQUFDLGFBQWE7Z0JBQ2xCLFFBQVEsRUFBQyxhQUFhO2dCQUN0QixRQUFRLEVBQUM7b0JBQ0wsR0FBRyxFQUFDLElBQUk7b0JBQ1IsR0FBRyxFQUFDLElBQUk7aUJBQ1g7Z0JBQ0QsS0FBSyxFQUFDO29CQUNGLE9BQU8sRUFBQyxFQUFFO2lCQUNiO2FBQ0o7U0FDSjtLQUNKLENBQUM7SUFFRixJQUFJLFNBQVMsR0FBRztRQUNaLEtBQUssRUFBQztZQUNGLFFBQVEsRUFBQyxJQUFJO1lBQ2IsV0FBVyxFQUFDLElBQUk7WUFDaEIsUUFBUSxFQUFDLCtCQUErQjtZQUN4QyxTQUFTLEVBQUMsU0FBUyxDQUFDLEtBQUs7U0FDNUI7UUFDRCxRQUFRLEVBQUM7WUFDTCxRQUFRLEVBQUMsSUFBSTtZQUNiLFdBQVcsRUFBQyxJQUFJO1lBQ2hCLFFBQVEsRUFBQyxzQkFBc0I7U0FDbEM7UUFDRCxVQUFVLEVBQUM7WUFDUCxRQUFRLEVBQUMsSUFBSTtZQUNiLFdBQVcsRUFBQyxJQUFJO1lBQ2hCLFFBQVEsRUFBQyxtQkFBbUI7WUFDNUIsU0FBUyxFQUFDLFNBQVMsQ0FBQyxVQUFVO1NBQ2pDO0tBQ0osQ0FBQztJQUlGLElBQUksR0FBRyxHQUFHLElBQUksY0FBYyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7SUFDdEQsR0FBRyxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsdURBQXVEO0lBQzdGLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNqQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDbkMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ1gseUVBQXlFO0lBRXpFLEtBQUs7SUFDTCxJQUFJLFNBQVMsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO0lBQzNCLENBQUMsQ0FBRSxnQkFBZ0IsQ0FBRSxDQUFDLFVBQVUsQ0FBQztRQUM3QixNQUFNLEVBQUUsSUFBSTtRQUNaLE9BQU8sRUFBRSxTQUFTO0tBQ3JCLENBQUMsQ0FBQztJQUVILENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUMsVUFBUyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDeEIsR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDdkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzFDLENBQUMsQ0FBQyxDQUFDO0lBRUgsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBQyxVQUFTLENBQUM7UUFDdkMsQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNoRCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFFUCxDQUFDLENBQUMsQ0FBQyJ9